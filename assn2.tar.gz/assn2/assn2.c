// Adam Armstrong
// CS 3060-002 Fall 2020
// Assignment 2 - The fork() and exec() System Calls

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.*/

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
	printf("\n________________________________________\n");
	printf("\nCS 3060: Assignment #2 - The fork() and exec() System Calls\n\n");

	//Your program will call the fork() system call at the very start.
	printf("Here we are in our fork example...\n");
	pid_t pid = fork();


	//The parent process will display a message indicating it has started.
	printf("PARENT %d initiated.\n", pid);


	//PID will then wait for a specific child process ID to complete.
	if (pid > 0) {
		printf("In the PARENT process, PID is %d\n", pid);
		printf("Waiting for CHILD.\n");
		int* status = 0;
		wait(status);

		/*Once the child process has completed,
		the parent process will display a message indicating that the child is complete
		and the parent will now terminate.*/
		printf("CHILD completed..\n");
		printf("PARENT will now terminate.\n");
	}//END if(pid > 0)


	else if (pid == 0) {
		//The child process will display a message indicating that it has started.
		printf("CHILD process initiated.\n");
		printf("In the CHILD process!\n");

		//If no arguments were provided, the child process will display a message indicating that it will terminate.
		if (argc == 1) {
			printf("No arguments provided.\n");
			printf("Terminating CHILD.\n");
		}

		/*If one or more arguments were provided on the command line,
		the child process will perform the appropriate exec() system call
		to load the new executable into memory with the appropriate arguments if provided.*/
		if (argc == 2) {
			printf("One argument provided.\n");
			printf("Executing %s.\n", argv[1]);
			execlp(argv[1], argv[1], NULL);
		}

		if (argc > 2) {
			printf("More than one argument provided.\n");
			execvp(argv[1], argv + 1);
		}
	}//END else if (pid == 0)


	else {
		printf("ERROR.\n");
		printf("Oh noes! There has been a problems.\n");
	}// END else

	printf("\n----------------------------------------\n\n");

	return 0;

}// END MAIN()
